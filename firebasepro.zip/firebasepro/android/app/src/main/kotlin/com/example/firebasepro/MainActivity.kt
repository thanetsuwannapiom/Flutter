package com.example.firebasepro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
