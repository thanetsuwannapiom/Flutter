import 'package:flutter/material.dart';
import 'package:homework1/shopping.dart';

class form extends StatefulWidget {
  const form({Key? key}): super(key: key);

  @override
  State<form> createState() => _formState();
}

class _formState extends State<form> {

  var _baseLengthName;
  var _heightName;

  final _baseLengtController = TextEditingController();
  final _heightController = TextEditingController();
  void initState(){
    super.initState();

    _baseLengtController.addListener(_updateText);
    _heightController.addListener(_updateText);
  }
  void _updateText(){
    setState(() {

      _baseLengthName = _baseLengtController.text;
      _heightName = _heightController.text;
    });
  }
  
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Test form')),
      body: Container(
        padding: EdgeInsets.all(20.0),
        child: Column(
          children: [

            TextFormField(
              controller: _baseLengtController,
              decoration: InputDecoration(
                labelText: "Length or Radius ",
                icon: Icon(Icons.verified_user_outlined),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextFormField(
              controller: _heightController,
              decoration: InputDecoration(
                labelText: "Width ",
                icon: Icon(Icons.verified_user_outlined),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            myBtn(context),
            SizedBox(height: 10),
            Text('Lenth : ${_baseLengtController.text}',
            style : TextStyle(fontSize: 20),
            ),
            Text('Width : ${_heightController.text}',
            style : TextStyle(fontSize: 20),
            ),
            
              
          ],
        ),
      ),
    );
  }

  Center myBtn(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Text(""),
          ElevatedButton(onPressed: (){
            Navigator.push(context,
            MaterialPageRoute(builder: (context){
              return formShopping(                
                baseLengthName: _baseLengtController.text,
                heightName: _heightController.text,
              );
            } 
            ),);
            
          },
          child: Text("Cal ", style: TextStyle(fontSize: 20),),
          style: ElevatedButton.styleFrom(
            fixedSize: Size(200, 70),
            backgroundColor: Colors.lightBlue,
          ),
            
          )
        ],
      ),
    );
  }
}