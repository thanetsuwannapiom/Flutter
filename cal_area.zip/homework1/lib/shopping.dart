import 'package:flutter/material.dart';

class formShopping extends StatelessWidget {
  formShopping({Key? key,  required this.baseLengthName ,required this.heightName}) : super(key: key);
  
  String baseLengthName;
  String heightName;


 bool isRectangle() {
    return heightName.isNotEmpty; // Check if height is provided
  }

  double calculateTotalPrice() {
    double height = double.tryParse(heightName) ?? 0.0;
    int baseLength = int.tryParse(baseLengthName) ?? 0;
    return isRectangle() ? baseLength * height : 0.0;
  }

  double calculateCircleArea() {
    double radius = double.tryParse(baseLengthName) ?? 0.0;
    return isRectangle() ? 0.0 : 3.14 * radius * radius;
  }

  double calculateCircleCircumference() {
    double radius = double.tryParse(baseLengthName) ?? 0.0;
    return isRectangle() ? 0.0 : 2 * 3.14 * radius;
  }

  double calculateRectanglePerimeter() {
    double height = double.tryParse(heightName) ?? 0.0;
    int baseLength = int.tryParse(baseLengthName) ?? 0;
    return isRectangle() ? 2 * (baseLength + height) : 0.0;
  }

  @override
  Widget build(BuildContext context) {
    double totalPrice = calculateTotalPrice();
    double circleArea = calculateCircleArea();
    double circleCircumference = calculateCircleCircumference();
    double rectanglePerimeter = calculateRectanglePerimeter();

    return Scaffold(
      appBar: AppBar(
        title: Text('แสดงผล'),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back),
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(20.0),
        child: ListView(
          children: [
            ListTile(
              leading: Icon(Icons.account_balance_wallet_outlined),
              title: Text(
                isRectangle() ? 'สี่เหลี่ยม\n$totalPrice' : 'วงกลม\n$circleArea',
              ),
              subtitle: Text(
                'เส้นรอบรูป\n${isRectangle() ? rectanglePerimeter : circleCircumference}',
              ),
            ),
          ],
        ),
      ),
    );
  }
}