package com.example.pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
