package com.example.joy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
